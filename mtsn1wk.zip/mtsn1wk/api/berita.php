<?php
// Mengatur header agar output selalu dalam format JSON dan UTF-8
header("Content-Type: application/json; charset=UTF-8");

// Memanggil file koneksi.
require_once '../admin/config.php';

// Fungsi untuk mengirim response JSON dan menghentikan skrip
function send_json_response($data, $status_code = 200) {
    http_response_code($status_code);
    echo json_encode($data);
    exit();
}

// --- Keamanan: Verifikasi API Key ---
$api_key = $_GET['api_key'] ?? '';
if (empty($api_key)) {
    send_json_response(['error' => 'API Key dibutuhkan'], 401);
}

// Cek API Key ke database
$izin_pengguna = null;
$sql_check_key = "SELECT izin FROM api_keys WHERE api_key = ? AND status = 'aktif' LIMIT 1";
if ($stmt_check = $conn->prepare($sql_check_key)) {
    $stmt_check->bind_param("s", $api_key);
    $stmt_check->execute();
    $result_key = $stmt_check->get_result();

    if ($result_key->num_rows === 0) {
        send_json_response(['error' => 'API Key tidak valid atau tidak aktif'], 403);
    }
    $izin_pengguna = $result_key->fetch_assoc()['izin'];
    $stmt_check->close();
} else {
    send_json_response(['error' => 'Kesalahan server saat verifikasi kunci'], 500);
}

// --- Menangani Permintaan (Request) ---
$method = $_SERVER['REQUEST_METHOD'];

// =================================================================
// LOGIKA UNTUK MEMBACA BERITA (GET)
// =================================================================
if ($method == 'GET') {
    $berita_list = [];
    $sql = "SELECT judul, isi, penulis, kategori, gambar_utama, gambar_2, gambar_3, tanggal_publikasi, slug FROM berita ORDER BY tanggal_publikasi DESC";

    if ($result = $conn->query($sql)) {
        while ($row = $result->fetch_assoc()) {
            $base_url = 'https://' . $_SERVER['HTTP_HOST'];
            $row['gambar_utama_url'] = !empty($row['gambar_utama']) ? $base_url . '/admin/uploads/berita/' . $row['gambar_utama'] : null;
            $row['gambar_2_url'] = !empty($row['gambar_2']) ? $base_url . '/admin/uploads/berita/' . $row['gambar_2'] : null;
            $row['gambar_3_url'] = !empty($row['gambar_3']) ? $base_url . '/admin/uploads/berita/' . $row['gambar_3'] : null;
            $berita_list[] = $row;
        }
        send_json_response($berita_list, 200);
    } else {
        send_json_response(['error' => 'Gagal mengambil data dari database'], 500);
    }
}

// =================================================================
// LOGIKA BARU UNTUK MENULIS BERITA (POST)
// =================================================================
elseif ($method == 'POST') {
    // Keamanan: Cek apakah pengguna punya izin 'tulis_berita'
    if (strpos($izin_pengguna, 'tulis_berita') === false) {
        send_json_response(['error' => 'API Key ini tidak memiliki izin untuk menulis berita.'], 403);
    }

    // Ambil data dari body request
    $judul = $_POST['judul'] ?? '';
    $isi = $_POST['isi'] ?? '';
    $penulis = $_POST['penulis'] ?? 'Tim Redaksi';
    $kategori = $_POST['kategori'] ?? 'Umum';

    // Validasi data
    if (empty($judul) || empty($isi)) {
        send_json_response(['error' => 'Judul dan Isi berita tidak boleh kosong.'], 400); // 400 Bad Request
    }

    // Proses upload gambar utama (wajib)
    if (!isset($_FILES['gambar_utama']) || $_FILES['gambar_utama']['error'] != 0) {
        send_json_response(['error' => 'Gambar utama wajib diunggah.'], 400);
    }

    $target_dir = "../admin/uploads/berita/";
    $file_ext = strtolower(pathinfo($_FILES['gambar_utama']['name'], PATHINFO_EXTENSION));
    $gambar_utama_db = uniqid('berita_', true) . '.' . $file_ext;

    if (!move_uploaded_file($_FILES['gambar_utama']['tmp_name'], $target_dir . $gambar_utama_db)) {
        send_json_response(['error' => 'Gagal mengunggah gambar utama.'], 500);
    }

    // Buat slug
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $judul)));

    // Simpan ke database
    $sql_insert = "INSERT INTO berita (judul, isi, penulis, kategori, gambar_utama, slug) VALUES (?, ?, ?, ?, ?, ?)";
    if ($stmt_insert = $conn->prepare($sql_insert)) {
        $stmt_insert->bind_param("ssssss", $judul, $isi, $penulis, $kategori, $gambar_utama_db, $slug);
        if ($stmt_insert->execute()) {
            send_json_response(['success' => true, 'message' => 'Berita berhasil dipublikasikan.'], 201); // 201 Created
        } else {
            send_json_response(['error' => 'Gagal menyimpan berita ke database.'], 500);
        }
        $stmt_insert->close();
    }
}

// Jika metode lain (PUT, DELETE), kirim pesan error
else {
    send_json_response(['error' => 'Metode permintaan tidak diizinkan'], 405);
}

$conn->close();
?>
