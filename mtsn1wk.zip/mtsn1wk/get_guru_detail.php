<?php
// Mengatur header agar outputnya adalah JSON
header('Content-Type: application/json');
include 'koneksi.php';

// Pastikan ada parameter ID yang dikirim
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['error' => 'ID Guru tidak ditemukan.']);
    exit();
}

$guru_id = (int)$_GET['id'];

// Ambil data guru dari database
$sql = "SELECT * FROM data_guru WHERE id = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("i", $guru_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $guru = $result->fetch_assoc();
    // Kirim data sebagai JSON
    echo json_encode($guru);
} else {
    // Jika tidak ada data, kirim pesan error
    echo json_encode(['error' => 'Data guru tidak ditemukan.']);
}

$stmt->close();
$koneksi->close();
?>
